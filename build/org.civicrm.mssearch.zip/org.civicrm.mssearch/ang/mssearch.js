(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('mssearch', [
    'crmUi', 'crmUtil', 'ngRoute'
  ]);
})(angular, CRM.$, CRM._);
